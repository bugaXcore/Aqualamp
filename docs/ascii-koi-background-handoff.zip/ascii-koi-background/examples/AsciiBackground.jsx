// React wrapper for ascii-bg.js.
// Copy ascii-bg.js and the *-frames.js files you need next to this file, or
// fix the import paths below. The scripts are imported inside an effect, so
// nothing touches `window` during server rendering (Next.js, Remix, ...).
//
//   <AsciiBackground clip="koi-close" color="#ffffff" opacity={0.4} zoom={1.4} />
//
// Any other prop (fontSize, speed, ramp, zoom, focusX, ...) is passed to
// AsciiBg as an option and can change live. Give your page content
// `position: relative` so it paints above the fixed canvas.

import { useEffect, useRef } from "react";

const CLIPS = {
  koi: () => import("./koi-frames.js"),
  "koi-close": () => import("./koi-close-frames.js"),
};

export default function AsciiBackground({
  clip = "koi",
  color = "#ffffff",
  opacity = 0.4,
  className,
  style,
  ...options
}) {
  const canvasRef = useRef(null);
  const bgRef = useRef(null);
  const optionsRef = useRef(options);
  optionsRef.current = options;
  const optionsKey = JSON.stringify(options);

  // Mount once, swap clips in place.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      await Promise.all([import("./ascii-bg.js"), CLIPS[clip]()]);
      if (cancelled) return;
      if (bgRef.current) return bgRef.current.setClip(window.ASCII_CLIPS[clip]);
      const bg = await window.AsciiBg.mount(canvasRef.current, window.ASCII_CLIPS[clip], optionsRef.current);
      if (cancelled) bg.destroy();
      else bgRef.current = bg;
    })();
    return () => { cancelled = true; };
  }, [clip]);

  useEffect(() => () => bgRef.current?.destroy(), []);

  useEffect(() => { bgRef.current?.set(optionsRef.current); }, [optionsKey]);

  // The glyph colour is read from CSS when the atlas is built.
  useEffect(() => { bgRef.current?.refresh(); }, [color]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={className}
      style={{
        position: "fixed",
        inset: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        color,
        opacity,
        ...style,
      }}
    />
  );
}
