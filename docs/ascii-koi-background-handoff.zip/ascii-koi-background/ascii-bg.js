// ascii-bg.js
// Draws a looping brightness clip (made by bake.py) as monochrome ASCII on a
// canvas. Glyphs are pre-rendered once into a small atlas and blitted per
// cell, and empty cells are skipped, so a full-screen grid stays cheap.
// The glyph colour is the canvas's CSS `color`.
//
//   const bg = await AsciiBg.mount(canvas, ASCII_CLIPS.koi, { fontSize: 12 });
//   bg.set({ speed: 0.5 });              // change any option live
//   await bg.setClip(ASCII_CLIPS.other); // swap to another baked clip
//   bg.refresh();                        // re-read the CSS colour, e.g. after a theme switch
//   bg.destroy();

(function () {
  const DEFAULTS = {
    ramp: " .:-=+*#%@",  // faint to dense; index 0 must be a space
    fontSize: 12,        // CSS px
    lineHeight: 1.25,    // cell height as a multiple of fontSize
    fontFamily: 'ui-monospace, "SF Mono", Menlo, Consolas, monospace',
    minAlpha: 0.35,      // alpha of the faintest glyph; the densest gets 1
    fps: 30,             // render cap; the clip is blended between its own frames
    speed: 1,
    focusX: 0.5,         // which part of the clip stays in view when cropped, 0..1
    focusY: 0.5,
    zoom: 1,
  };

  async function decode(clip) {
    const bin = atob(clip.data);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  // Bilinear taps for each cell centre along one axis: the two source offsets
  // (already multiplied by stride) and the weight of the second one.
  function taps(count, cell, offset, scale, len, stride) {
    const i0 = new Int32Array(count), i1 = new Int32Array(count), wt = new Float32Array(count);
    for (let k = 0; k < count; k++) {
      const p = ((k + 0.5) * cell - offset) / scale - 0.5;
      const f = Math.floor(p);
      i0[k] = Math.min(len - 1, Math.max(0, f)) * stride;
      i1[k] = Math.min(len - 1, Math.max(0, f + 1)) * stride;
      wt[k] = p - f;
    }
    return [i0, i1, wt];
  }

  async function mount(canvas, clip, options) {
    const opts = Object.assign({}, DEFAULTS, options);
    let frames = await decode(clip);
    let size = clip.w * clip.h;
    const ctx = canvas.getContext("2d");
    const atlas = document.createElement("canvas");
    const actx = atlas.getContext("2d");
    const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)");
    const darkScheme = matchMedia("(prefers-color-scheme: dark)");

    let cw, ch, cols, rows, idxScale, xi0, xi1, xw, yi0, yi1, yw;
    let raf = 0, last = 0, clock = 0;

    function fontSpec() {
      return `${opts.fontSize * (window.devicePixelRatio || 1)}px ${opts.fontFamily}`;
    }

    function layout() {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.max(1, Math.round(canvas.clientWidth * dpr));
      canvas.height = Math.max(1, Math.round(canvas.clientHeight * dpr));

      // Glyph atlas: one cell per ramp entry, alpha rising with density.
      const n = opts.ramp.length;
      actx.font = fontSpec();
      cw = Math.max(1, Math.round(actx.measureText("M").width));
      ch = Math.max(1, Math.round(opts.fontSize * opts.lineHeight * dpr));
      atlas.width = cw * n;
      atlas.height = ch;
      actx.font = fontSpec();
      actx.fillStyle = getComputedStyle(canvas).color;
      actx.textAlign = "center";
      actx.textBaseline = "middle";
      for (let i = 1; i < n; i++) {
        actx.globalAlpha = opts.minAlpha + (1 - opts.minAlpha) * (i - 1) / Math.max(1, n - 2);
        actx.fillText(opts.ramp[i], i * cw + cw / 2, ch / 2);
      }
      idxScale = (n - 1) / (clip.levels - 1);

      // "Cover" fit of the clip onto the cell grid, like object-fit: cover.
      cols = Math.ceil(canvas.width / cw);
      rows = Math.ceil(canvas.height / ch);
      const s = Math.max(canvas.width / clip.w, canvas.height / clip.h) * opts.zoom;
      const ox = (canvas.width - clip.w * s) * opts.focusX;
      const oy = (canvas.height - clip.h * s) * opts.focusY;
      [xi0, xi1, xw] = taps(cols, cw, ox, s, clip.w, 1);
      [yi0, yi1, yw] = taps(rows, ch, oy, s, clip.h, clip.w);
    }

    function draw(ms) {
      const t = (ms / 1000) * clip.fps;
      const f = Math.floor(t);
      const A = (f % clip.frames) * size;
      const B = ((f + 1) % clip.frames) * size;
      const ft = t - f;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let r = 0; r < rows; r++) {
        const y0 = yi0[r], y1 = yi1[r], wy = yw[r], dy = r * ch;
        for (let c = 0; c < cols; c++) {
          const p00 = y0 + xi0[c], p01 = y0 + xi1[c], p10 = y1 + xi0[c], p11 = y1 + xi1[c];
          const wx = xw[c];
          const a0 = frames[A + p00] + (frames[A + p01] - frames[A + p00]) * wx;
          const a1 = frames[A + p10] + (frames[A + p11] - frames[A + p10]) * wx;
          const b0 = frames[B + p00] + (frames[B + p01] - frames[B + p00]) * wx;
          const b1 = frames[B + p10] + (frames[B + p11] - frames[B + p10]) * wx;
          const va = a0 + (a1 - a0) * wy;
          const v = va + (b0 + (b1 - b0) * wy - va) * ft;
          const idx = (v * idxScale + 0.5) | 0;
          if (idx > 0) ctx.drawImage(atlas, idx * cw, 0, cw, ch, c * cw, dy, cw, ch);
        }
      }
    }

    function tick(now) {
      raf = requestAnimationFrame(tick);
      if (now - last < 1000 / opts.fps - 1) return;
      clock += Math.min(now - last, 100) * opts.speed; // no jump after a hidden tab
      last = now;
      draw(clock);
    }

    function play() {
      cancelAnimationFrame(raf);
      if (reduceMotion.matches) draw(clock); // hold a still frame
      else raf = requestAnimationFrame(tick);
    }

    async function refresh() {
      await document.fonts.load(fontSpec()).catch(() => {});
      layout();
      play();
    }

    const ro = new ResizeObserver(refresh);
    ro.observe(canvas);
    reduceMotion.addEventListener("change", play);
    darkScheme.addEventListener("change", refresh);
    await refresh();

    return {
      set(o) { Object.assign(opts, o); return refresh(); },
      async setClip(next) {
        const data = await decode(next);
        clip = next;
        frames = data;
        size = clip.w * clip.h;
        clock = 0;
        return refresh();
      },
      refresh,
      destroy() {
        cancelAnimationFrame(raf);
        ro.disconnect();
        reduceMotion.removeEventListener("change", play);
        darkScheme.removeEventListener("change", refresh);
      },
    };
  }

  window.AsciiBg = { mount };
})();
