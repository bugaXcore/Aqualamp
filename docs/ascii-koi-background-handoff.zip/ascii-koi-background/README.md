# ASCII Koi Background

A subtle, monochrome, looping ASCII animation for page backgrounds. Two koi circle in a dark pond, redrawn as text on a `<canvas>` behind the page.

| Koi wide (default) | Koi close | Koi close, light theme |
| --- | --- | --- |
| ![Koi wide, dark](previews/koi-wide-dark.jpg) | ![Koi close, dark](previews/koi-close-dark.jpg) | ![Koi close, light](previews/koi-close-light.jpg) |

It is not a video of ASCII art. The source videos are reduced offline to a small grid of brightness values, and the page draws the characters live. That gives you:

- **Crisp glyphs at any size and pixel density**: nothing is scaled, every character is drawn at native resolution.
- **A tiny payload**: 55 KB (wide) or 171 KB (close) of data plus a 7 KB script, versus the several MB a full-screen ASCII video typically weighs.
- **Styling from CSS**: glyph colour is the canvas `color`, strength is its `opacity`. Dark, light or brand colours need no re-export.
- **Live tuning**: cell size, speed, zoom and character set can change at runtime.
- **No autoplay rules**: a `<video>` background stops on iOS Low Power Mode; this doesn't use one.

## What's in the folder

| File | What it is |
| --- | --- |
| `ascii-bg.js` | The renderer. No dependencies, no build step. Exposes `window.AsciiBg`. |
| `koi-frames.js` | Baked clip `koi` (wide shot): 170 frames, 14.2 s loop, 55 KB. |
| `koi-close-frames.js` | Baked clip `koi-close` (close shot, stronger ripples): 171 frames, 14.2 s loop, 171 KB. |
| `index.html` | Demo page with a **Tune** panel (clip, cell size, opacity, speed, zoom, glyph set, light/dark). |
| `minimal.html` | The smallest working integration. Start here when wiring it into a site. |
| `examples/AsciiBackground.jsx` | React wrapper (SSR-safe). |
| `bake.py` | Turns a video into a `*-frames.js` clip. |
| `source/` | The two original videos the clips were baked from. |
| `previews/` | Screenshots used above. |

## Run the demo

Serve the folder over HTTP and open it:

```bash
python -m http.server 8000
```

Then go to http://localhost:8000 (demo) or http://localhost:8000/minimal.html.

## Add it to a page

```html
<canvas class="ascii-bg" aria-hidden="true"></canvas>

<script src="koi-frames.js"></script>
<script src="ascii-bg.js"></script>
<script>
  AsciiBg.mount(document.querySelector(".ascii-bg"), ASCII_CLIPS.koi);
</script>
```

```css
.ascii-bg {
  position: fixed;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  color: #ffffff;  /* glyph colour */
  opacity: 0.4;    /* overall strength; 0.3–0.5 reads as "background" */
}
main { position: relative; } /* page content paints above the canvas */
```

**Layering:** keep the canvas at the default `z-index` and give your content `position: relative` (as above). Don't put the canvas at `z-index: -1` if `<body>` has its own background colour, because the body background will cover it.

**Using the close clip:** load `koi-close-frames.js` instead and pass `ASCII_CLIPS["koi-close"]`. You can load several clip files and switch at runtime with `setClip`.

## Options

Pass these as the third argument to `mount`, or change them later with `set`.

| Option | Default | What it does |
| --- | --- | --- |
| `ramp` | `" .:-=+*#%@"` | Characters from faint to dense. The first must be a space. The demo also has a soft set `" .,:;-=+"` and a block set `" ░▒▓█"`. |
| `fontSize` | `12` | Cell size in CSS px. Smaller is finer and busier. |
| `lineHeight` | `1.25` | Cell height as a multiple of `fontSize`. |
| `fontFamily` | system monospace | Any monospace stack. Web fonts are awaited before drawing. |
| `minAlpha` | `0.35` | Opacity of the faintest character; the densest is fully opaque. Lower values make the ripples quieter. |
| `speed` | `1` | Playback speed. `0.5` is calmer. |
| `zoom` | `1` | Scales the clip beyond "cover". Around `1.4` makes the wide clip's fish read clearly on big screens. |
| `focusX`, `focusY` | `0.5` | Which part of the clip stays in view when it's cropped, like `object-position`. |
| `fps` | `30` | Render cap. The 12 fps clip is blended between frames, so 30 looks smooth. |

## API

```js
const bg = await AsciiBg.mount(canvas, ASCII_CLIPS.koi, { fontSize: 12 });

bg.set({ speed: 0.5, zoom: 1.4 });      // change options live
await bg.setClip(ASCII_CLIPS["koi-close"]); // swap clip (restarts its loop)
bg.refresh();                           // re-read the CSS colour, e.g. after a theme toggle
bg.destroy();                           // stop and detach listeners
```

## Theming

The glyph colour is read from the canvas's CSS `color` when the glyphs are drawn into their atlas.

- When the OS switches light/dark (`prefers-color-scheme`), the renderer refreshes itself.
- When **your own** theme toggle changes the colour (a class or `data-theme`), call `bg.refresh()` afterwards. `index.html` shows this.

For a light page, use dark ink on a light background, e.g. `color: #111111` on `#f6f6f6`. The fish then draw as dark characters.

## React

`examples/AsciiBackground.jsx` wraps the renderer. Copy it next to `ascii-bg.js` and the frame files, or fix its import paths.

```jsx
<AsciiBackground clip="koi-close" color="#ffffff" opacity={0.4} zoom={1.4} />
```

The scripts are imported inside an effect, so it is safe with server rendering. Option props update live, and changing `clip` swaps the clip in place. **This wrapper has not been run in a React project yet.** The plain HTML version has.

## Baking a new clip

Needs Python 3.9+, `numpy`, and `ffmpeg` on PATH.

```bash
python bake.py source/koi-close.mp4 koi-close-frames.js
```

The output name sets the clip name: `name-frames.js` registers `ASCII_CLIPS.name`. Re-running on the same video gives a byte-identical file.

What the bake does:

1. **Samples** the video at 160×90 and 12 fps in greyscale. The page resamples this to whatever grid fits the screen.
2. **Finds the loop.** These generated clips ease back into their first pose and then hold it for ~0.8 s. The bake ends the loop at the first late frame that matches the opening pose, so there's no pause at the wrap. It prints the cut frame.
3. **Removes the static background.** It subtracts each pixel's median over time, so haze and vignetting disappear and only the moving fish and ripples become characters.
4. **Maps brightness** to 16 levels with a curve that lifts faint detail, then gzips the levels and embeds them as base64.

Constants at the top of `bake.py`:

| Constant | Default | Raise it to... |
| --- | --- | --- |
| `BLACK` | `4` | Hide more faint noise and ripples. |
| `WHITE` | `140` | Make bright areas less dense. |
| `GAMMA` | `0.5` | Toward 1 to make faint ripples quieter; lower to bring them up. |
| `W`, `H` | `160, 90` | Get finer detail at the cost of a bigger file. Keep the video's aspect ratio. |
| `FPS` | `12` | Get smoother fast motion at the cost of a bigger file. |

What makes a good source video: a static camera, a dark and even background, a bright subject that moves, and a clip made to loop (it returns to its first frame). 10–20 s is plenty.

## How the renderer works

- The clip is decoded once with the browser's built-in `DecompressionStream` into one byte per sample.
- Each character in `ramp` is drawn once into a small offscreen atlas, with alpha rising with density. Each frame then blits one atlas cell per non-empty grid cell, and empty cells are skipped. Most of the pond is empty, so this stays cheap at full screen.
- Each cell samples the clip with bilinear filtering, using a "cover" fit, and blends between the two nearest clip frames for smooth motion.
- It draws at up to `fps`, sized to the device pixel ratio with cells snapped to whole device pixels so glyphs stay sharp. It relayouts on resize through a `ResizeObserver`.

## Accessibility and performance

- `aria-hidden="true"` and `pointer-events: none`: screen readers and clicks ignore it.
- `prefers-reduced-motion: reduce`: it shows one still frame and doesn't animate. It also reacts if the setting changes while the page is open.
- In background tabs, drawing stops automatically (`requestAnimationFrame`), and it resumes without jumping ahead.
- Keep `opacity` around 0.3–0.5 behind body text so contrast stays high.

## Browser support and testing

Needs `DecompressionStream` (Chrome 80+, Edge 80+, Firefox 113+, Safari 16.4+) and `ResizeObserver`.

| Tested | Not tested yet |
| --- | --- |
| Chromium-based in-app browser, served over HTTP: both clips, clip switching, light and dark, 375 px phone width (no horizontal scroll), no console errors. | Safari (macOS and iOS), Firefox, Android, low-end devices, opening the HTML straight from disk (`file://`), the React wrapper. |

## Known limitations and next steps

- Clip data is base64 inside a JS file (about 33 % overhead) so it works with a plain `<script>` tag. For production you could serve the raw gzip as a binary file and `fetch` it.
- It uses Canvas 2D. Very dense grids (`fontSize` under ~8 on 4K screens) would be cheaper as a WebGL shader.
- Only one colour per canvas, which is monochrome by design.
- The source videos were generated with MiniMax (per their original file names). Check the usage terms before shipping.
